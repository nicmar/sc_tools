================================================================================
        Space Chef Save Manager v1.0.1
================================================================================

A cross-platform tool for managing Space Chef save files and backups.


How to Run:
  1. Open terminal in this folder
  2. Make executable: chmod +x SpaceChefSaveManager
  3. Run: ./SpaceChefSaveManager
  4. Or: Double-click the file in your file manager

Default Save Location:
  ~/.local/share/BlueGooGames/Space Chef/Saves

If the save location is not found automatically:
  - Click "Browse..." to locate your Saves folder
  - Make sure Space Chef has been run at least once


Features:
  - View all your Space Chef saves with player names and progress
  - Create manual backups of your saves
  - Restore from any backup (with automatic safety backup)
  - Quick access to save and log folders

Usage:
  1. Launch SpaceChefSaveManager
  2. Select a player from the list
  3. Use "View Backups" to see and restore backups
  4. Use "Create Backup" to make a manual backup
  5. Use "Open Save Folder" or "Open Player Logs" for quick access

Troubleshooting:
  - Save location not found?
    Use the "Browse..." button to manually select your Saves folder

  - No saves showing?
    Make sure you've run Space Chef at least once

  - Backup restore failed?
    Close Space Chef before restoring
    Make sure you have write permissions to the Saves folder

Support:
  This is an unofficial community tool for Space Chef players.
  Not affiliated with BlueGoo Games.

================================================================================
                    Made with love for Space Chef players
================================================================================